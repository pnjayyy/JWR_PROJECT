<?php
include 'redirect_to.php';

// Include the db_connect.php file to connect to the database
require_once 'db_connect.php';

// Define an array of table names and corresponding variables
$tables = [
    'product' => 'totalProducts',
    'category' => 'totalCategories',
    'customer' => 'totalCustomers',
    'orders' => 'totalOrders'
];

// Fetch data for each table and assign the values to variables
foreach ($tables as $table => $variable) {
    $query = "SELECT COUNT(*) AS total FROM $table";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $$variable = $result['total'];
}

// ฟังก์ชันที่ดึงข้อมูลตามช่วงเวลา
function getDataByPeriod($conn, $period) {
    if ($period == '1_month') {
        $query = "SELECT COUNT(*) AS total FROM orders WHERE order_date >= CURDATE() - INTERVAL 1 MONTH";
    } elseif ($period == '3_months') {
        $query = "SELECT COUNT(*) AS total FROM orders WHERE order_date >= CURDATE() - INTERVAL 3 MONTH";
    } elseif ($period == '6_months') {
        $query = "SELECT COUNT(*) AS total FROM orders WHERE order_date >= CURDATE() - INTERVAL 6 MONTH";
    } elseif ($period == '1_year') {
        $query = "SELECT COUNT(*) AS total FROM orders WHERE order_date >= CURDATE() - INTERVAL 1 YEAR";
    }
    
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total'];
}

// กำหนดค่าช่วงเวลาตามที่เลือกใน URL
$period = isset($_GET['period']) ? $_GET['period'] : '1_month';  // ค่าเริ่มต้นเป็น 1 เดือน

// ดึงข้อมูลจำนวนคำสั่งซื้อในช่วงเวลาที่เลือก
$totalOrdersInPeriod = getDataByPeriod($conn, $period);
$conn = null;
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JWR Warehouse Management System</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* กำหนดสไตล์ให้กับกราฟและส่วนต่างๆ */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7f7f7;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            position: relative; /* สำหรับจัดการตำแหน่งปุ่มกลับ */
        }

        /* ปุ่มกลับไปหน้า home */
        .back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color:rgb(245, 53, 27);
            color: white;
            padding: 8px 16px; /* ปรับขนาดให้เล็กลง */
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px; /* ขนาดตัวอักษรเล็กลง */
        }

        .card {
            padding: 20px;
            background-color: #f4f4f4;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2em;
            color: #333;
        }

        .period-btns {
            text-align: center;
            margin-bottom: 30px;
        }

        .period-btns a {
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 5px;
            font-size: 16px;
        }

        .period-btns a:hover {
            background-color: #2980b9;
        }

        /* สไตล์สำหรับกราฟ */
        .chart-container {
            width: 100%;
            height: 400px;
        }

        /* สไตล์สำหรับตาราง */
        .table-container {
            margin: 20px 0;
            padding: 20px;
            background-color: #f4f4f4;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table-container h3 {
            margin-bottom: 20px;
            font-size: 1.5em;
            color: #333;
        }

        .dashboard-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .dashboard-table th, .dashboard-table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .dashboard-table th {
            background-color: #3498db;
            color: white;
        }

        .view-btn {
            padding: 8px 16px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
        }

        .view-btn:hover {
            background-color: #2980b9;
        }

        .period-btns {
    position: absolute;
    top: 74px; /* เว้นระยะจากขอบบน */
    right: 8px; /* เว้นระยะจากขอบขวา */
    background-color: white; /* พื้นหลังสีขาว */
    padding: 5px 10px;
    border-radius: 8px;
    display: flex;
    gap: 5px; /* ระยะห่างระหว่างปุ่ม */
}

.period-btns a {
    padding: 5px 10px;
    font-size: 14px; /* ขนาดตัวอักษรเล็กลง */
    background-color: #3498db;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}

.period-btns a:hover {
    background-color: #2980b9;
}

    </style>
</head>
<body>

<div class="container">
    <!-- ปุ่มกลับไปหน้า home -->
    <a href="home.php" class="back-btn"><i class="fas fa-arrow-left"></i> กลับไปหน้าหลัก</a>

    <h2>สรุปภาพรวม</h2>

    <!-- ปุ่มให้เลือกช่วงเวลา -->
    <div class="card">
    <!-- ปุ่มเลือกช่วงเวลา -->
    <div class="period-btns">
        <a href="?period=1_month">1 เดือน</a>
        <a href="?period=3_months">3 เดือน</a>
        <a href="?period=6_months">6 เดือน</a>
        <a href="?period=1_year">1 ปี</a>
    </div>

    <!-- กราฟสำหรับแสดงสรุปภาพรวม -->
    <div class="card">
        <canvas id="overviewChart" class="chart-container"></canvas>
    </div>

    <div class="table-container">
        <h3>ข้อมูลรายละเอียดสรุปภาพรวม</h3>
        <table class="dashboard-table">
            <thead>
                <tr>
                    <th>หัวข้อ</th>
                    <th>จำนวน</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>สินค้าทั้งหมด</td>
                    <td><?php echo $totalProducts; ?></td>
                </tr>
                <tr>
                    <td>หมวดหมู่สินค้า</td>
                    <td><?php echo $totalCategories; ?></td>
                </tr>
                <tr>
                    <td>ลูกค้าทั้งหมด</td>
                    <td><?php echo $totalCustomers; ?></td>
                </tr>
                <tr>
                    <td>คำสั่งซื้อทั้งหมด (ช่วงเวลา)</td>
                    <td><?php echo $totalOrdersInPeriod; ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    // กำหนดข้อมูลที่จะแสดงในกราฟ
    const ctx = document.getElementById('overviewChart').getContext('2d');
    const overviewChart = new Chart(ctx, {
        type: 'bar', // กำหนดให้เป็นกราฟแท่ง
        data: {
            labels: ['สินค้าทั้งหมด', 'หมวดหมู่สินค้า', 'ลูกค้าทั้งหมด', 'คำสั่งซื้อทั้งหมด'],
            datasets: [{
                label: 'จำนวน',
                data: [<?php echo $totalProducts; ?>, <?php echo $totalCategories; ?>, <?php echo $totalCustomers; ?>, <?php echo $totalOrdersInPeriod; ?>],
                backgroundColor: ['#3498db', '#2ecc71', '#f39c12', '#e74c3c'],
                borderColor: ['#2980b9', '#27ae60', '#f1c40f', '#c0392b'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

</body>
</html>
