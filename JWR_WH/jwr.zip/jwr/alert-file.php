<?php
// เรียกไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db_connect.php';

// ดึงค่าจำนวนสินค้าคงเหลือจากฐานข้อมูล
$sql = "SELECT SUM(quantity) AS total_quantity FROM product"; // หรือเปลี่ยนเป็น WHERE category_id = X ถ้าต้องการเช็คเฉพาะบางหมวด
$stmt = $conn->prepare($sql);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$quantity = $row['total_quantity']; // เก็บค่าจำนวนสินค้า


?>
<!DOCTYPE html>
<html>
<head>
    <style>
    .popup {
    display: none;
    position: fixed;
    right: 20px;
    bottom: -100px; /* ซ่อนก่อนแล้วค่อยเลื่อนขึ้น */
    background: rgba(255, 0, 0, 0.9);
    color: white;
    padding: 15px 20px;
    border-radius: 10px;
    font-size: 16px;
    font-weight: bold;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
    transition: bottom 0.5s ease-in-out; /* ทำให้เด้งขึ้นนุ่มนวล */
    z-index: 1000;
}

    </style>
<body>


<!-- ป็อปอัพแจ้งเตือน -->
<div id="stockAlert" class="popup">
    <span id="stockMessage"></span>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    let quantity = <?php echo $quantity; ?>; // ดึงค่าจาก PHP
    checkStock(quantity);
});

function checkStock(quantity) {
    let alertBox = document.getElementById("stockAlert");
    let message = document.getElementById("stockMessage");

    if (quantity >= 30) {
        message.innerText = "📦 ของเต็มสต๊อกแล้ว !";
        alertBox.style.background = "rgba(0, 128, 0, 0.9)"; // สีเขียว
    } else if (quantity < 5) {
        message.innerText = "⚠️ ของใกล้จะหมดแล้วนะ !";
        alertBox.style.background = "rgba(255, 0, 0, 0.9)"; // สีแดง
    } else {
        message.innerText = "✅ ของยังเหลืออยู่";
        alertBox.style.background = "rgba(255, 165, 0, 0.9)"; // สีส้ม
    }

    // แสดง popup โดยเลื่อนขึ้น
    alertBox.style.display = "block";
    setTimeout(() => {
        alertBox.style.bottom = "20px"; // เลื่อนขึ้นมาจากขอบล่าง
    }, 100);

    // ซ่อน popup หลังจาก 5 วินาที
    setTimeout(() => {
        alertBox.style.bottom = "-100px"; // เลื่อนกลับลงไป
        setTimeout(() => {
            alertBox.style.display = "none";
        }, 500);
    }, 5000);
}
</script>
</html>
